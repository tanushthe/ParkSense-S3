# ParkSense-S3 Hardware Pinout, Slot ROIs & BLE GATT Specification

## 1. OV2640 Camera Pin Mapping (ESP32-S3-N16R8)

| Signal | GPIO | Notes |
|---|---|---|
| `XCLK` | 15 | 10 MHz clock |
| `SIOD` (SDA) | 4 | SCCB I2C data |
| `SIOC` (SCL) | 5 | SCCB I2C clock |
| `VSYNC` | 6 | Frame sync |
| `HREF` | 7 | Line sync |
| `PCLK` | 13 | Pixel clock |
| `Y2` (D0) | 11 | Data bit 0 |
| `Y3` (D1) | 9 | Data bit 1 |
| `Y4` (D2) | 8 | Data bit 2 |
| `Y5` (D3) | 10 | Data bit 3 |
| `Y6` (D4) | 12 | Data bit 4 |
| `Y7` (D5) | 18 | Data bit 5 |
| `Y8` (D6) | 17 | Data bit 6 |
| `Y9` (D7) | 16 | Data bit 7 |
| `PWDN` / `RESET` | -1 | Not connected |

## 2. QVGA (320x240) Parking Slot ROIs

Each ROI is cropped from the decoded RGB888 frame and resized to `48x48x3` for INT8 TinyML inference (`INPUT_SCALE_MODE = 1`, `[0.0..1.0]`).

| Slot | `x` | `y` | `w` | `h` |
|---|---:|---:|---:|---:|
| Slot 1 | 20 | 75 | 55 | 65 |
| Slot 2 | 78 | 75 | 55 | 65 |
| Slot 3 | 135 | 75 | 55 | 65 |
| Slot 4 | 192 | 75 | 58 | 65 |
| Slot 5 | 250 | 75 | 60 | 65 |

## 3. BLE GATT Profile (NimBLE-Arduino 2.x)

- **Advertising Name:** `ParkSense-S3` (primary adv packet: Flags + Name = 17 bytes)
- **Scan Response:** Complete 128-bit Service UUID (18 bytes)
- **TX Power:** `+9 dBm` (`NimBLEDevice::setPower(9)`)
- **MTU:** `128` bytes (prevents 20-byte truncation of 34-byte telemetry strings)
- **Wi-Fi Coexistence:** `WiFi.setSleep(true)` enabled pre- and post-association; NimBLE starts after Wi-Fi connects; auto-restart watchdog every 5 s if idle advertising drops.

| Entity | UUID | Properties | Format / Example |
|---|---|---|---|
| **Service** | `4fafc201-1fb5-459e-8fcc-c5c9c331914b` | Primary | ParkSense Telemetry & Control |
| **Slot Status Characteristic** | `beb5483e-36e1-4688-b7f5-ea07361b26a8` | `READ`, `NOTIFY` | `AVAIL:3/5\|S1:1,S2:0,S3:1,S4:0,S5:0` |
| **Control Characteristic** | `1c95d5e3-d8f7-413a-bf3d-7a2e5d7be87e` | `WRITE` | UTF-8 `THR:75` (range `50`–`99`%) |

## 4. Local HTTP Endpoints (Port 80)

| Endpoint | Method | Description |
|---|---|---|
| `/` | `GET` | 3-tab Web Dashboard (Live Monitor, Diagnostics, Settings & Logs) |
| `/capture` | `GET` | Live QVGA JPEG snapshot (`Cache-Control: no-store`) |
| `/api/status` | `GET` | JSON telemetry (slots, confidence, latency, BLE clients/payload, RSSI, heap/PSRAM) |
| `/api/settings` | `GET` | Query params `thr` (`0.50`–`0.99`) and `intv` (`500`–`10000` ms) |
| `/export.csv` | `GET` | Downloads rolling occupancy & latency CSV log |
