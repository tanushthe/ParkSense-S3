#include <WiFi.h>
#include <WebServer.h>
#include <NimBLEDevice.h>
#include "esp_camera.h"
#include "img_converters.h"
#include <MicroTFLite.h>
#include "model_data.h"

// Copy secrets.example.h to secrets.h and set your Wi-Fi credentials.
#if __has_include("secrets.h")
  #include "secrets.h"
#else
  #include "secrets.example.h"
#endif

// ================= 1. BLE & MODEL CONFIGURATION =================
#define BLE_DEVICE_NAME   "ParkSense-S3"
#define BLE_SERVICE_UUID  "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define BLE_SLOT_UUID     "beb5483e-36e1-4688-b7f5-ea07361b26a8"
#define BLE_CTRL_UUID     "1c95d5e3-d8f7-413a-bf3d-7a2e5d7be87e"

// Input scale mode: 1 -> [0.0..1.0] (scale ~0.00392), 0 -> [0.0..255.0], 2 -> [-1.0..1.0]
#define INPUT_SCALE_MODE 1

// ================= 2. ESP32-S3-N16R8 CAMERA PINS =================
#define PWDN_GPIO_NUM  -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM  15
#define SIOD_GPIO_NUM  4
#define SIOC_GPIO_NUM  5
#define Y9_GPIO_NUM    16
#define Y8_GPIO_NUM    17
#define Y7_GPIO_NUM    18
#define Y6_GPIO_NUM    12
#define Y5_GPIO_NUM    10
#define Y4_GPIO_NUM    8
#define Y3_GPIO_NUM    9
#define Y2_GPIO_NUM    11
#define VSYNC_GPIO_NUM 6
#define HREF_GPIO_NUM  7
#define PCLK_GPIO_NUM  13

// ================= 3. PARKING SLOT COORDINATES (QVGA 320x240) =================
struct SlotROI { int x; int y; int w; int h; };
SlotROI slots[5] = {
  { 20,  75, 55, 65 },  // Slot 1
  { 78,  75, 55, 65 },  // Slot 2
  { 135, 75, 55, 65 },  // Slot 3
  { 192, 75, 58, 65 },  // Slot 4
  { 250, 75, 60, 65 }   // Slot 5
};

// ================= 4. TINYML, BLE & SYSTEM STATE =================
constexpr int kTensorArenaSize = 80 * 1024;
alignas(16) uint8_t tensor_arena[kTensorArenaSize];

WebServer server(80);
uint8_t* rgb888Buf = nullptr;

NimBLEServer* pBleServer = nullptr;
NimBLECharacteristic* pSlotChar = nullptr;
NimBLECharacteristic* pCtrlChar = nullptr;
bool bleOk = false;
String lastBlePayload = "INIT";

float slotConf[5] = {0, 0, 0, 0, 0};
bool slotOccupied[5] = {false, false, false, false, false};
float confThreshold = 0.70f;
int pollIntervalMs = 2000;

unsigned long lastInferenceMs = 0;
unsigned long lastBleCheckMs = 0;
uint32_t inferenceDurationMs = 0;
uint32_t totalCycles = 0;
uint32_t fbFailCount = 0;

bool cameraOk = false;
bool modelOk = false;
bool lastFrameOk = false;
bool inferenceBusy = false;

String csvLog = "Timestamp_s,Slot1,Slot2,Slot3,Slot4,Slot5,Available,Latency_ms\n";

inline float scalePixel(int val) {
#if INPUT_SCALE_MODE == 0
  return (float)val;
#elif INPUT_SCALE_MODE == 1
  return val / 255.0f;
#else
  return (val / 127.5f) - 1.0f;
#endif
}

// BLE Server Callbacks: log connections and guarantee advertising restarts
class ServerCallbacks : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer* pServer, NimBLEConnInfo& connInfo) override {
    Serial.printf("[BLE] Client connected (total=%d)\n", pServer->getConnectedCount());
  }
  void onDisconnect(NimBLEServer* pServer, NimBLEConnInfo& connInfo, int reason) override {
    Serial.printf("[BLE] Client disconnected (reason=%d), restarting advertising\n", reason);
    NimBLEDevice::startAdvertising();
  }
};

// BLE Write Callback: accepts "THR:75" from phone to adjust confidence threshold
class CtrlCharCallbacks : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic* pCharacteristic, NimBLEConnInfo& connInfo) override {
    std::string rx = pCharacteristic->getValue();
    if (rx.rfind("THR:", 0) == 0 && rx.length() > 4) {
      float pct = atof(rx.substr(4).c_str());
      if (pct >= 50.0f && pct <= 99.0f) {
        confThreshold = pct / 100.0f;
        Serial.printf("[BLE] Updated threshold via BLE to %.0f%%\n", pct);
      }
    }
  }
};

// ================= 5. BLE GATT SERVER INIT (NIMBLE 2.x) =================
void initBLE() {
  NimBLEDevice::init(BLE_DEVICE_NAME);
  NimBLEDevice::setPower(9);     // NimBLE 2.x uses dBm (+9 dBm max on ESP32-S3)
  NimBLEDevice::setMTU(128);     // Allow full 34-byte telemetry notifications without truncation

  pBleServer = NimBLEDevice::createServer();
  pBleServer->setCallbacks(new ServerCallbacks());
  pBleServer->advertiseOnDisconnect(true);

  NimBLEService* pService = pBleServer->createService(BLE_SERVICE_UUID);

  pSlotChar = pService->createCharacteristic(
    BLE_SLOT_UUID,
    NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY
  );
  pSlotChar->setValue("AVAIL:5/5|S1:0,S2:0,S3:0,S4:0,S5:0");

  pCtrlChar = pService->createCharacteristic(
    BLE_CTRL_UUID,
    NIMBLE_PROPERTY::WRITE
  );
  pCtrlChar->setCallbacks(new CtrlCharCallbacks());

  pService->start();

  // Primary advertising packet (17 bytes <= 31): Flags + Name so every scanner sees "ParkSense-S3" immediately
  NimBLEAdvertisementData advData;
  advData.setFlags(BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP);
  advData.setName(BLE_DEVICE_NAME);

  // Scan response packet (18 bytes <= 31): 128-bit Service UUID
  NimBLEAdvertisementData scanRespData;
  scanRespData.setCompleteServices(NimBLEUUID(BLE_SERVICE_UUID));

  NimBLEAdvertising* pAdv = NimBLEDevice::getAdvertising();
  pAdv->enableScanResponse(true);
  pAdv->setAdvertisementData(advData);
  pAdv->setScanResponseData(scanRespData);
  // 100ms - 200ms interval: fast discovery while coexisting with 2.4GHz Wi-Fi
  pAdv->setMinInterval(160);
  pAdv->setMaxInterval(320);

  bool advOk = pAdv->start();
  bleOk = advOk;

  Serial.printf("[BLE] Name='%s' | AdvStarted=%d | IsAdv=%d | MAC=%s\n",
                BLE_DEVICE_NAME,
                advOk ? 1 : 0,
                pAdv->isAdvertising() ? 1 : 0,
                NimBLEDevice::getAddress().toString().c_str());
}

// ================= 6. CAMERA INIT (ESP32-S3-N16R8) =================
bool initCamera() {
  camera_config_t config = {};
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;
  config.xclk_freq_hz = 10000000;
  config.frame_size   = FRAMESIZE_QVGA;
  config.pixel_format = PIXFORMAT_JPEG;
  config.fb_location  = CAMERA_FB_IN_PSRAM;
  config.grab_mode    = CAMERA_GRAB_LATEST;
  config.jpeg_quality = 12;
  config.fb_count     = 2;

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("[CAM] Init failed: 0x%x\n", err);
    return false;
  }

  for (int i = 0; i < 2; i++) {
    camera_fb_t* fb = esp_camera_fb_get();
    if (fb) esp_camera_fb_return(fb);
    delay(60);
  }
  Serial.println("[CAM] OV2640 initialized OK (QVGA 320x240, PSRAM)");
  return true;
}

// ================= 7. RUN TINYML INFERENCE & PUSH BLE NOTIFY =================
void runParkingInference() {
  if (!cameraOk || !modelOk || !rgb888Buf || inferenceBusy) return;
  inferenceBusy = true;

  unsigned long t0 = millis();
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) {
    fbFailCount++;
    lastFrameOk = false;
    inferenceBusy = false;
    Serial.printf("[CAM] Frame grab NULL (fails=%lu)\n", (unsigned long)fbFailCount);
    return;
  }
  lastFrameOk = true;

  if (fmt2rgb888(fb->buf, fb->len, PIXFORMAT_JPEG, rgb888Buf)) {
    for (int s = 0; s < 5; s++) {
      for (int dy = 0; dy < 48; dy++) {
        int sy = constrain(slots[s].y + (dy * slots[s].h) / 48, 0, 239);
        for (int dx = 0; dx < 48; dx++) {
          int sx = constrain(slots[s].x + (dx * slots[s].w) / 48, 0, 319);

          int srcIdx = (sy * 320 + sx) * 3;
          int dstIdx = (dy * 48 + dx) * 3;

          int rVal = rgb888Buf[srcIdx + 2];
          int gVal = rgb888Buf[srcIdx + 1];
          int bVal = rgb888Buf[srcIdx + 0];

          ModelSetInput(scalePixel(rVal), dstIdx);
          ModelSetInput(scalePixel(gVal), dstIdx + 1);
          ModelSetInput(scalePixel(bVal), dstIdx + 2);
        }
      }

      if (ModelRunInference()) {
        float prob = constrain(ModelGetOutput(0), 0.0f, 1.0f);
        slotConf[s] = prob;
        slotOccupied[s] = (prob >= confThreshold);
      }
    }
  }

  esp_camera_fb_return(fb);
  inferenceDurationMs = millis() - t0;
  totalCycles++;

  int avail = 0;
  for (int i = 0; i < 5; i++) if (!slotOccupied[i]) avail++;

  // Update BLE GATT Characteristic & notify connected phone
  if (bleOk && pSlotChar != nullptr) {
    lastBlePayload = "AVAIL:" + String(avail) + "/5|S1:" + String(slotOccupied[0]) +
                     ",S2:" + String(slotOccupied[1]) + ",S3:" + String(slotOccupied[2]) +
                     ",S4:" + String(slotOccupied[3]) + ",S5:" + String(slotOccupied[4]);
    pSlotChar->setValue(lastBlePayload.c_str());
    if (pBleServer->getConnectedCount() > 0) {
      pSlotChar->notify();
    }
  }

  csvLog += String(millis() / 1000) + "," +
            String(slotOccupied[0]) + "," + String(slotOccupied[1]) + "," +
            String(slotOccupied[2]) + "," + String(slotOccupied[3]) + "," +
            String(slotOccupied[4]) + "," + String(avail) + "," +
            String(inferenceDurationMs) + "\n";

  if (csvLog.length() > 4000) {
    int firstNl = csvLog.indexOf('\n');
    int secondNl = csvLog.indexOf('\n', firstNl + 1);
    if (secondNl > firstNl) {
      csvLog = csvLog.substring(0, firstNl + 1) + csvLog.substring(secondNl + 1);
    }
  }

  Serial.printf("[ML+BLE] Cycle #%lu | Avail: %d/5 | Lat: %lu ms | BLE Clients: %d | Adv: %d\n",
                (unsigned long)totalCycles, avail, (unsigned long)inferenceDurationMs,
                bleOk ? pBleServer->getConnectedCount() : 0,
                bleOk ? (NimBLEDevice::getAdvertising()->isAdvertising() ? 1 : 0) : 0);
  inferenceBusy = false;
}

// ================= 8. NON-BLOCKING 3-TAB WEB DASHBOARD =================
const char DASHBOARD_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ParkSense S3 - TinyML + BLE Smart Parking</title>
  <style>
    body { font-family: Arial, sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 16px; }
    .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; padding-bottom: 10px; }
    .tabs { display: flex; gap: 8px; margin: 16px 0; }
    .tab { padding: 10px 16px; background: #1e293b; border: none; color: #cbd5e1; border-radius: 6px; cursor: pointer; font-weight: bold; }
    .tab.active { background: #2563eb; color: #fff; }
    .panel { display: none; background: #1e293b; padding: 16px; border-radius: 8px; }
    .panel.active { display: block; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; margin-top: 12px; }
    .slot { padding: 14px; border-radius: 8px; text-align: center; font-weight: bold; }
    .free { background: #14532d; border: 2px solid #22c55e; }
    .busy { background: #7f1d1d; border: 2px solid #ef4444; }
    .cam-wrap { position: relative; display: inline-block; margin-top: 16px; width: 100%; max-width: 480px; }
    .cam-wrap img { width: 100%; min-height: 180px; background: #020617; display: block; border-radius: 8px; border: 2px solid #475569; }
    .cam-wrap canvas { position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    td, th { border: 1px solid #334155; padding: 8px; text-align: left; }
    button.action { background: #2563eb; color: white; border: none; padding: 10px 14px; border-radius: 6px; cursor: pointer; margin-top: 10px; }
  </style>
</head>
<body>
  <div class="header">
    <h2>ParkSense S3 (TinyML + BLE)</h2>
    <span id="badge">FW v1.1.0 | INT8 + NimBLE</span>
  </div>

  <div class="tabs">
    <button class="tab active" onclick="showTab(0)">1. Live Monitor</button>
    <button class="tab" onclick="showTab(1)">2. Diagnostics</button>
    <button class="tab" onclick="showTab(2)">3. Settings & Logs</button>
  </div>

  <div class="panel active" id="tab0">
    <h3>Available Slots: <span id="avail">-</span> / 5 &nbsp;|&nbsp; Latency: <span id="lat">-</span> ms</h3>
    <div class="grid" id="slots"></div>
    <div class="cam-wrap">
      <img id="cam" alt="Waiting for OV2640 camera frame...">
      <canvas id="roiCanvas" width="320" height="240"></canvas>
    </div>
    <p style="font-size:12px;color:#94a3b8;">OV2640 QVGA Feed (320x240) + Simultaneous NimBLE GATT Telemetry</p>
  </div>

  <div class="panel" id="tab1">
    <h3>Hardware, TinyML & BLE Telemetry</h3>
    <table>
      <tr><th>Metric</th><th>Value</th></tr>
      <tr><td>Firmware Version</td><td>v1.1.0-INT8-BLE (ESP32-S3-N16R8)</td></tr>
      <tr><td>Camera OV2640 Init / Frame Grab</td><td id="camSt">-</td></tr>
      <tr><td>LiteRT INT8 Model Status</td><td id="modSt">-</td></tr>
      <tr><td>BLE GATT Server (ParkSense-S3)</td><td id="bleSt">-</td></tr>
      <tr><td>Last BLE GATT Payload</td><td id="blePay">-</td></tr>
      <tr><td>Wi-Fi RSSI Signal</td><td id="rssi">-</td></tr>
      <tr><td>Free Heap / Free PSRAM</td><td id="mem">-</td></tr>
      <tr><td>System Uptime / Total Cycles</td><td id="up">-</td></tr>
    </table>
    <button class="action" onclick="runSelfTest()">Run Hardware Self-Test</button>
    <p id="testRes"></p>
  </div>

  <div class="panel" id="tab2">
    <h3>Thresholds & Data Export</h3>
    <label>Occupancy Confidence Threshold (%): <input type="number" id="thr" value="70" min="50" max="99"></label><br><br>
    <label>Polling Interval (ms): <input type="number" id="intv" value="2000" min="500" max="10000"></label><br>
    <button class="action" onclick="saveSettings()">Apply Settings</button>
    <a href="/export.csv"><button class="action" style="background:#059669;">Download CSV Log</button></a>
    <p id="setRes"></p>
  </div>

<script>
const rois = [
  {x:20,  y:75, w:55, h:65},
  {x:78,  y:75, w:55, h:65},
  {x:135, y:75, w:55, h:65},
  {x:192, y:75, w:58, h:65},
  {x:250, y:75, w:60, h:65}
];
let currentTab = 0;

function drawOverlay(slotStates) {
  const c = document.getElementById('roiCanvas');
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, 320, 240);
  ctx.lineWidth = 2;
  ctx.font = 'bold 11px Arial';
  rois.forEach((r, i) => {
    const occ = slotStates && slotStates[i] ? slotStates[i].occ : false;
    ctx.strokeStyle = occ ? '#ef4444' : '#22c55e';
    ctx.strokeRect(r.x, r.y, r.w, r.h);
    ctx.fillStyle = occ ? '#ef4444' : '#22c55e';
    ctx.fillText('S' + (i + 1), r.x + 3, r.y - 4);
  });
}

function showTab(n) {
  currentTab = n;
  document.querySelectorAll('.tab').forEach((t, i) => t.classList.toggle('active', i === n));
  document.querySelectorAll('.panel').forEach((p, i) => p.classList.toggle('active', i === n));
}

function loadNextFrame() {
  return new Promise((resolve) => {
    const img = document.getElementById('cam');
    const done = () => { img.onload = null; img.onerror = null; resolve(); };
    img.onload = done;
    img.onerror = done;
    img.src = '/capture?t=' + Date.now();
  });
}

async function pollLoop() {
  try {
    const r = await fetch('/api/status');
    const d = await r.json();
    document.getElementById('avail').innerText = d.available;
    document.getElementById('lat').innerText = d.latency_ms;
    document.getElementById('camSt').innerText =
      (d.cam_ok ? 'Init PASS' : 'Init FAIL') + ' | ' +
      (d.frame_ok ? 'Frame Grab OK' : 'Frame Grab NULL (' + d.fb_fails + ' fails)');
    document.getElementById('modSt').innerText = d.mod_ok ? 'PASS (10.12 KB INT8)' : 'FAIL';
    document.getElementById('bleSt').innerText = d.ble_ok ? ('Active (' + d.ble_clients + ' connected)') : 'OFF';
    document.getElementById('blePay').innerText = d.ble_payload;
    document.getElementById('rssi').innerText = d.rssi + ' dBm';
    document.getElementById('mem').innerText = d.heap_kb + ' KB / ' + d.psram_kb + ' KB';
    document.getElementById('up').innerText = d.uptime_s + ' s (' + d.cycles + ' inferences)';

    let html = '';
    d.slots.forEach((s, i) => {
      html += `<div class="slot ${s.occ ? 'busy' : 'free'}">Slot ${i+1}<br>${s.occ ? 'OCCUPIED' : 'EMPTY'}<br><small>${(s.conf*100).toFixed(1)}%</small></div>`;
    });
    document.getElementById('slots').innerHTML = html;
    drawOverlay(d.slots);

    if (currentTab === 0 && d.frame_ok) {
      await loadNextFrame();
    }
  } catch (e) {}
  setTimeout(pollLoop, 1500);
}

function runSelfTest() {
  const cam = document.getElementById('camSt').innerText;
  const mod = document.getElementById('modSt').innerText;
  const ble = document.getElementById('bleSt').innerText;
  document.getElementById('testRes').innerText = 'SELF-TEST -> Camera: ' + cam + ' | Model: ' + mod + ' | BLE: ' + ble;
}

async function saveSettings() {
  const thr = document.getElementById('thr').value / 100.0;
  const intv = document.getElementById('intv').value;
  await fetch(`/api/settings?thr=${thr}&intv=${intv}`);
  document.getElementById('setRes').innerText = 'Settings updated on ESP32-S3!';
}

drawOverlay(null);
pollLoop();
</script>
</body>
</html>
)rawliteral";

// ================= 9. HTTP ENDPOINTS & SETUP =================
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n=== ParkSense S3 v1.1.0 (TinyML + NimBLE) Booting ===");

  rgb888Buf = (uint8_t*)ps_malloc(320 * 240 * 3);
  if (!rgb888Buf) {
    Serial.println("[MEM] ERROR: PSRAM rgb888Buf allocation failed! Enable OPI PSRAM.");
  }

  cameraOk = initCamera();
  modelOk = ModelInit(g_parking_model_data, tensor_arena, kTensorArenaSize);
  Serial.println(modelOk ? "[ML] INT8 Model initialized OK" : "[ML] ERROR: ModelInit failed");

  // 1. Connect Wi-Fi FIRST with modem sleep enabled (required for BLE coexistence)
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(true);
  delay(100);
  WiFi.setSleep(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  Serial.print("[WIFI] Connecting");
  unsigned long wifiStart = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - wifiStart < 15000) {
    delay(300);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    WiFi.setSleep(true); // Ensure modem sleep stays active post-association
    Serial.println("\n[WIFI] Connected! IP Address: " + WiFi.localIP().toString());
  } else {
    Serial.printf("\n[WIFI] Timed out (status=%d). Continuing in BLE-only mode.\n", WiFi.status());
  }

  // 2. Start NimBLE AFTER Wi-Fi association completes
  delay(300);
  initBLE();

  runParkingInference();

  server.on("/", []() {
    server.send_P(200, "text/html", DASHBOARD_HTML);
  });

  server.on("/capture", []() {
    if (!cameraOk) {
      server.send(503, "text/plain", "Camera not initialized");
      return;
    }
    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) {
      server.send(503, "text/plain", "Camera frame buffer unavailable");
      return;
    }
    server.sendHeader("Cache-Control", "no-store");
    server.send_P(200, "image/jpeg", (const char*)fb->buf, fb->len);
    esp_camera_fb_return(fb);
  });

  server.on("/api/status", []() {
    int avail = 0;
    for (int i = 0; i < 5; i++) if (!slotOccupied[i]) avail++;
    int bleClients = (bleOk && pBleServer != nullptr) ? pBleServer->getConnectedCount() : 0;
    String json = "{\"available\":" + String(avail) +
                  ",\"latency_ms\":" + String(inferenceDurationMs) +
                  ",\"cam_ok\":" + String(cameraOk ? "true" : "false") +
                  ",\"frame_ok\":" + String(lastFrameOk ? "true" : "false") +
                  ",\"fb_fails\":" + String(fbFailCount) +
                  ",\"mod_ok\":" + String(modelOk ? "true" : "false") +
                  ",\"ble_ok\":" + String(bleOk ? "true" : "false") +
                  ",\"ble_clients\":" + String(bleClients) +
                  ",\"ble_payload\":\"" + lastBlePayload + "\"" +
                  ",\"rssi\":" + String(WiFi.RSSI()) +
                  ",\"heap_kb\":" + String(ESP.getFreeHeap() / 1024) +
                  ",\"psram_kb\":" + String(ESP.getFreePsram() / 1024) +
                  ",\"uptime_s\":" + String(millis() / 1000) +
                  ",\"cycles\":" + String(totalCycles) + ",\"slots\":[";
    for (int i = 0; i < 5; i++) {
      json += "{\"occ\":" + String(slotOccupied[i] ? "true" : "false") +
              ",\"conf\":" + String(slotConf[i], 3) + "}";
      if (i < 4) json += ",";
    }
    json += "]}";
    server.send(200, "application/json", json);
  });

  server.on("/api/settings", []() {
    if (server.hasArg("thr"))  confThreshold = constrain(server.arg("thr").toFloat(), 0.50f, 0.99f);
    if (server.hasArg("intv")) pollIntervalMs = constrain(server.arg("intv").toInt(), 500, 10000);
    server.send(200, "text/plain", "OK");
  });

  server.on("/export.csv", []() {
    server.sendHeader("Content-Disposition", "attachment; filename=parking_log.csv");
    server.send(200, "text/csv", csvLog);
  });

  server.begin();
  Serial.println("[HTTP] Web dashboard server started on port 80");
}

void loop() {
  server.handleClient();

  // Keep BLE advertising alive if no client is connected
  if (bleOk && pBleServer != nullptr && millis() - lastBleCheckMs >= 5000) {
    lastBleCheckMs = millis();
    if (pBleServer->getConnectedCount() == 0 && !NimBLEDevice::getAdvertising()->isAdvertising()) {
      Serial.println("[BLE] Advertising stopped unexpectedly -> restarting");
      NimBLEDevice::startAdvertising();
    }
  }

  if (millis() - lastInferenceMs >= (unsigned long)pollIntervalMs) {
    lastInferenceMs = millis();
    runParkingInference();
  }

  delay(5); // Yield CPU briefly so BLE and Wi-Fi background tasks stay responsive
}
