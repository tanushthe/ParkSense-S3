#pragma once
#include <cstdint>

/*
 * PLACEHOLDER MODEL HEADER
 * ------------------------------------------------------------------------
 * Replace this file with your exported INT8 LiteRT / TensorFlow Lite Micro
 * C array header (~10.12 KB quantized CNN for 48x48x3 RGB slot crops).
 *
 * Expected symbol name referenced by ParkSense_S3.ino:
 *   alignas(16) const unsigned char g_parking_model_data[] = { ... };
 *   const unsigned int g_parking_model_data_len = ...;
 *
 * Model I/O contract:
 *   - Input  : 48 x 48 x 3 RGB tensor (scaled to [0.0..1.0] when INPUT_SCALE_MODE == 1)
 *   - Output : 1 scalar occupancy probability in [0.0..1.0]
 */

alignas(16) const unsigned char g_parking_model_data[] = {
  0x00 // Replace with your actual model_data.h byte array before flashing
};
const unsigned int g_parking_model_data_len = sizeof(g_parking_model_data);
