#pragma once

// Copy this file to "secrets.h" in the same folder and fill in your Wi-Fi credentials.
// "secrets.h" is listed in .gitignore so your credentials are never pushed to GitHub.

static const char* WIFI_SSID = "YOUR_WIFI_SSID";
static const char* WIFI_PASS = "YOUR_WIFI_PASSWORD";
